package monitor;

public class MyCustomException extends Exception {

    public MyCustomException(String str){
        super(str);


    }
}
