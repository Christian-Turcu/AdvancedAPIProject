package monitor.Misc;

import database.Database;
import model.User;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class cabbage {

    public static void setSprouts(){
        try {

            File f = new File("data.db");
            System.out.println("Database exists"+f.exists());
            if(!f.exists()){
                Database.getConnection();
                User u1 = new User(1,"Admin","password","admin@company.com", User.ROLE.ADMIN.toString(),"0000", User.LOCK.UNLOCKED.toString());
                User u2 = new User(2,"Developer","password","developer@company.com", User.ROLE.DEVELOPER.toString(),"1111",User.LOCK.UNLOCKED.toString());
                User u3 = new User(3,"Lead","password","lead@company.com", User.ROLE.LEAD.toString(),"2222", User.LOCK.UNLOCKED.toString());
                createDefaultUser(u1);
                createDefaultUser(u2);
                createDefaultUser(u3);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private static int createDefaultUser(User user) throws SQLException {
        Connection con = Database.getConnection();
        String sql = "INSERT INTO user (name, password,email, role, pin, lock ) VALUES (?, ?, ?, ?,  ?, ?)";
        System.out.println(user.getLock()+": "+user.getRole()+ ": "+user.getPin());

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPassword());
        ps.setString(3, user.getEmail());
        ps.setString(4, user.getRole().toString());
        ps.setString(5, user.getPin());
        ps.setString(6, user.getLock().toString());

        int result = ps.executeUpdate();
        Database.closePreparedStatement(ps);
        Database.closeConnection(con);
        return result;
    }
}
