package controller;

import database.Database;
import database.LogDAOImpl;
import database.UserDAOImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.LogginUser;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private AnchorPane anchorPaneLogin;

    @FXML
    private Button btnRegisterNewUser;

    @FXML
    private Button btnSubmitLogin;

    @FXML
    private TextField textUserName;

    @FXML
    private TextField textUserPassword;

    UserDAOImpl db;

    @FXML
    void onLoginButtonClicked(ActionEvent event) throws IOException, SQLException {
        String name = textUserName.getText().trim();
        String password = textUserPassword.getText().trim();
        User u = db.readLoggedInUser(name,password);
        LogginUser.setUser(u);
        String dest = "/view/main-view.fxml";
        MainApplication.navigateTo(anchorPaneLogin,dest);
    }

    @FXML
    void onRegisterButtonClicked(ActionEvent event) throws IOException {
        String dest = "/view/register-view.fxml";
        MainApplication.navigateTo(anchorPaneLogin,dest);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        db = new UserDAOImpl();
        User currentUser = LogginUser.getUser();

        if(currentUser !=null){
            textUserName.setText(currentUser.getName());
            textUserPassword.setText(currentUser.getPassword());
        }else{
            textUserName.setText("");
            textUserPassword.setText("");
        }

    }
}
