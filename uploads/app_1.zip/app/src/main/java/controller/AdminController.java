package controller;

import database.UserDAOImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Log;
import model.LogginUser;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    @FXML
    private AnchorPane anchorPaneAdmin;

    @FXML
    private Button btnBack;

    @FXML
    private Button btnDelete;

    @FXML
    private TableView<User> tabelViewAdmin;

    @FXML
    private TableColumn<User, String> columnName;

    @FXML
    private TableColumn<User, String> columnPassword;

    @FXML
    private TableColumn<User, String> columnRole;

    @FXML
    private TableColumn<User, String> colummPin;

    @FXML
    private TableColumn<User, String> columnLocked;


    @FXML
    private ComboBox<String> comboLock;

    @FXML
    private ComboBox<String> comboRole;

    @FXML
    private Label labelInfo;


    @FXML
    private TextField textNewPassword;

    @FXML
    private TextField textNewPin;

    public UserDAOImpl db;

    private ObservableList<String> roles;
    private ObservableList<String> lock;
    private String pin;
    User currentUser;

    @FXML
    void onBackButtonClicked(ActionEvent event) throws IOException {
        String dest = "/view/login-view.fxml";
        MainApplication.navigateTo(anchorPaneAdmin, dest);
    }

    @FXML
    void onDeleteButtonClicked(ActionEvent event) throws IOException, SQLException {
        int row = tabelViewAdmin.getSelectionModel().getSelectedIndex();
        if (row >= 0) {
            delete(row);
            tabelViewAdmin.setItems(populateUsers());
        }

    }

    @FXML
    void onUpdateButtonClicked(ActionEvent event) throws SQLException {
        int row = tabelViewAdmin.getSelectionModel().getSelectedIndex();
        if (row >= 0) {
            update(row);
            textNewPassword.setText("");
            textNewPin.setText("");
            comboRole.setValue(roles.get(2));
            comboLock.setValue(lock.get(0));
            tabelViewAdmin.setItems(populateUsers());
        }
    }

    private void setUpTable() {
        db = new UserDAOImpl();
        pin = "0000";
        tabelViewAdmin.setEditable(true);
        columnName.setCellValueFactory(new PropertyValueFactory<User, String>("name"));
        columnPassword.setCellValueFactory(new PropertyValueFactory<User, String>("password"));
        colummPin.setCellValueFactory(new PropertyValueFactory<User, String>("pin"));
        columnRole.setCellValueFactory(new PropertyValueFactory<User, String>("role"));
        columnLocked.setCellValueFactory(new PropertyValueFactory<User, String>("lock"));
        try {
            tabelViewAdmin.setItems(populateUsers());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        tabelViewAdmin.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                textNewPassword.setText(newSelection.getPassword());
                textNewPin.setText(newSelection.getPin());
                comboRole.setValue(newSelection.getRole().toString());
                comboLock.setValue(newSelection.getLock().toString());
            }
        });
    }

    private void update(int row) throws SQLException {
        User u = (User) tabelViewAdmin.getItems().get(row);
        u.setPin(textNewPin.getText().trim());
        u.setPassword(textNewPassword.getText().trim());
        String r = comboRole.getValue();
        String l = comboLock.getValue();
        System.out.println(r);
        System.out.println(l);
        u.setRole(User.ROLE.valueOf(r));
        u.setLock(User.LOCK.valueOf(l));

        db = new UserDAOImpl();
        db.update(u);

    }
    private void delete(int row) throws SQLException {
        TextInputDialog dialog = new TextInputDialog("");
        dialog.setTitle("");
        dialog.setHeaderText("Security Control");
        dialog.setContentText("Please enter your pin to delete:");
        Optional<String> result = dialog.showAndWait();
        String s = result.toString();
        System.out.println(s);
        if (row >= 0) {
            if (result.isPresent()) {
                System.out.println("Your pin: " + result.get());
                User u = (User) tabelViewAdmin.getItems().get(row);
                if (currentUser != null && currentUser.getRole().toString().equals("ADMIN")&&(result.get().equals(currentUser.getPin())) ||(result.get().equals(pin))) {
                    tabelViewAdmin.getItems().remove(row);
                    tabelViewAdmin.getSelectionModel().clearSelection();
                    db.delete(u);
                    MainApplication.logData(new Log(0,"WARN",u.getName()+"Deleted ",new Date().toString()));
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning ");
                    alert.setHeaderText("Incorrect Pin Entered");
                    alert.setContentText("");
                    alert.showAndWait();
                    MainApplication.logData(new Log(0,"WARN","Failed to Deleted ",new Date().toString()));
                }
            }
        }
    }


    void setUpComboBoxRoles() {
        roles = FXCollections.observableArrayList();
        roles.add(User.ROLE.DEVELOPER.toString());
        roles.add(User.ROLE.LEAD.toString());
        roles.add(User.ROLE.ADMIN.toString());
        comboRole.setItems(roles);

        lock = FXCollections.observableArrayList();
        lock.add(User.LOCK.LOCKED.toString());
        lock.add(User.LOCK.UNLOCKED.toString());
        comboLock.setItems(lock);

    }

    private ObservableList<User> populateUsers() throws SQLException {
        UserDAOImpl db = new UserDAOImpl();
        List list = db.readAll();
        ObservableList<User> u = FXCollections.observableArrayList(list);
        return u;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setUpTable();
        setUpComboBoxRoles();

        currentUser = LogginUser.getUser();
        if(currentUser !=null){
            labelInfo.setText(currentUser.getName()+" is logged In");
        }else{
            labelInfo.setText("");
        }


    }
}
