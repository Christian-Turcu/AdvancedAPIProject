package controller;

import database.UserDAOImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.LogginUser;
import model.User;
import register.PasswordFactory;
import security.encryption;

import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {


    @FXML
    private AnchorPane anchorPaneRegister;

    @FXML
    private Button btnRegister;

    @FXML
    private Label labelFeedback;

    @FXML
    private TextField textConfirmPassword;

    @FXML
    private TextField textEmail;

    @FXML
    private TextField textName;

    @FXML
    private TextField textPassword;

    @FXML
    private TextField textPin;

    @FXML
    void onRegisterUser(ActionEvent event) throws IOException, SQLException, NoSuchAlgorithmException {
        String name = textName.getText().trim();
        String password1 = textPassword.getText().trim();
        String password2 = textConfirmPassword.getText().trim();
        String email = textEmail.getText().trim();
        String pin = textPin.getText().trim();
        int pinNumber =0;
        System.out.println(pin);

        if(name.isBlank() || password1.isBlank() || password2.isBlank() || email.isBlank() || pin.isEmpty()){
            System.out.println("Fill in all Entries");
            labelFeedback.setText("Fill in all fields");
            return;
        }

        try {
            pinNumber = Integer.parseInt(pin);
            pin = String.valueOf(pinNumber);

        }catch(Exception e){
            labelFeedback.setText("Use numerical only");
            return;
        }

        PasswordFactory passwordFactory = new PasswordFactory();
        String p = passwordFactory.confirmPassworValid(password1,password2);
        System.out.println(p);
        labelFeedback.setText(p);

        if(p.equals("OK")){
            User u = new User();
            UserDAOImpl dbu = new UserDAOImpl();
            encryption enc = new encryption();
            enc.setEncryption("MD5");
            u.setName(name);
            u.setPassword(enc.getHash(password1, false));
            u.setEmail(email);
            u.setPin(pin);
            LogginUser.setUser(u);
            dbu.create(u);
            String dest = "/view/login-view.fxml";
            MainApplication.navigateTo(anchorPaneRegister,dest);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
