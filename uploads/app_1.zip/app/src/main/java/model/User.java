package model;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

public class User {
    private int id;
    private String name;
    private String password;
    private String email;
    private String pin;
    public ObjectProperty<LOCK> lock;
    public ObjectProperty<ROLE> role;

    public User() {
        this.id = 0;
        this.name = "";
        this.password = "";
        this.email = "";
        this.pin ="";
        this.lock = new SimpleObjectProperty<>(LOCK.LOCKED);
        this.role = new SimpleObjectProperty<>(ROLE.DEVELOPER);

    }

    public User(Integer id, String name, String password, String email, String role, String pin, String lock) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.email = email;
        this.role = new SimpleObjectProperty<>(ROLE.valueOf(role));
        this.pin = pin;
        this.lock = new SimpleObjectProperty<>(LOCK.valueOf(lock));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public LOCK getLock() {
        return lock.get();
    }

    public ObjectProperty<LOCK> lockProperty() {
        return lock;
    }

    public void setLock(LOCK lock) {
        this.lock.set(lock);
    }

    public ROLE getRole() {
        return role.get();
    }

    public ObjectProperty<ROLE> roleProperty() {
        return role;
    }

    public void setRole(ROLE role) {
        this.role.set(role);
    }

    public static enum LOCK {LOCKED, UNLOCKED}
    public static enum ROLE {ADMIN, DEVELOPER, LEAD,TEST}

}
