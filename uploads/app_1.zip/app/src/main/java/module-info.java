module app {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires okhttp3;
    exports controller;
    exports model;
    exports database;
    exports register;

    opens controller to javafx.fxml;
    opens model to javafx.fxml;
    opens register to javafx.fxml;
    opens database to javafx.fxml;

}