package database;

import model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {


    @Override
    public int create(User user) throws SQLException {
        Connection con = Database.getConnection();
        String sql = "INSERT INTO user (name, password, email, role,pin,lock) VALUES (?, ?, ?, ?, ?,?)";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPassword());
        ps.setString(3, user.getEmail());
        ps.setString(4, String.valueOf(user.getRole()));
        ps.setString(5, user.getPin());
        ps.setString(6, String.valueOf(user.getLock()));

        int result = ps.executeUpdate();

        Database.closePreparedStatement(ps);
        Database.closeConnection(con);

        return result;

    }

    @Override
    public User readOne(int id) throws SQLException {
        Connection con = Database.getConnection();
        User user = null;
        System.out.println(id);
        String sql = "SELECT * FROM user WHERE id = ? ";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            Integer _id = rs.getInt("id");
            String userName = rs.getString("name");
            String userPassword = rs.getString("password");
            String userEmail = rs.getString("email");
            String userRole = rs.getString("role");
            String userPin = rs.getString("pin");
            String userLock = rs.getString("lock");
            user = new User(_id,userName, userPassword, userEmail, userRole,userPin, userLock);
        }
        Database.closeResultSet(rs);
        Database.closePreparedStatement(ps);
        Database.closeConnection(con);
        return user;
    }

    @Override
    public int update(User user) throws SQLException {
        Connection connection = Database.getConnection();
        System.out.println(user.getName()+" "+user.getPassword()+" "+user.getPin());
        String sql = "UPDATE user set name = ?, password = ?, role = ?, lock =?, pin = ? where id = ?";

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPassword());
        ps.setString(3, String.valueOf(user.getRole()));
        ps.setString(4, String.valueOf(user.getLock()));
        ps.setString(5, user.getPin());
        ps.setInt(6, user.getId());

        int result = ps.executeUpdate();
        Database.closePreparedStatement(ps);
        Database.closeConnection(connection);
        return result;

    }

    @Override
    public int delete(User user) throws SQLException {
        Connection connection = Database.getConnection();

        String sql = "DELETE  FROM user WHERE name =? AND password = ?";
        System.out.println(sql);

        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getPassword());
        int result = ps.executeUpdate();
        Database.closePreparedStatement(ps);
        Database.closeConnection(connection);
        return result;
    }

    @Override
    public List<User> readAll() throws SQLException {
        Connection con = Database.getConnection();
        String sql = "SELECT * FROM user";
        List<User> users = new ArrayList<>();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
            Integer _id = rs.getInt("id");
            String userName = rs.getString("name");
            String userPassword = rs.getString("password");
            String userEmail = rs.getString("email");
            String userRole = rs.getString("role");
            String userPin = rs.getString("pin");
            String userLock = rs.getString("lock");
            User user = new User(_id,userName, userPassword, userEmail, userRole,userPin, userLock);
            users.add(user);
        }
        return users;
    }

    @Override
    public int checkExists(String a, String b) throws SQLException {
        int count = 0;
        User user= null;
        Connection con = Database.getConnection();

        String query = "SELECT COUNT(*) FROM user WHERE name = ? AND password = ?";
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1,a);
        ps.setString(2,b);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            count = rs.getInt(1);
        }
        Database.closeResultSet(rs);
        Database.closePreparedStatement(ps);
        Database.closeConnection(con);
        return count;
    }

    @Override
    public User readLoggedInUser(String a, String b) throws SQLException {
        Connection con = Database.getConnection();
        User user = null;
        System.out.println(a + ""+ b);
        String sql = "SELECT * FROM user WHERE name = ? AND password =?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, a);
        ps.setString(2,b);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            Integer _id = rs.getInt("id");
            String userName = rs.getString("name");
            String userPassword = rs.getString("password");
            String userEmail = rs.getString("email");
            String userRole = rs.getString("role");
            String userPin = rs.getString("pin");
            String userLock = rs.getString("lock");
            user = new User(_id,userName, userPassword, userEmail, userRole,userPin, userLock);
        }
        Database.closeResultSet(rs);
        Database.closePreparedStatement(ps);
        Database.closeConnection(con);
        return user;

    }
}
