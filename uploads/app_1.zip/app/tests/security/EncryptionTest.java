package security;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.security.NoSuchAlgorithmException;

public class EncryptionTest {

    security.encryption encryption;
    String pass;
    String passHash;
    String newPass;

    @BeforeMethod
    public void setUp() {
        encryption = new encryption();
    }

    @AfterMethod
    public void tearDown() {
        encryption = null;
    }


    @Test(description = "this will hashing with MD5", priority = 1)
    public void testGetHashMD5() throws NoSuchAlgorithmException {
        pass = "password";
        passHash = "5f4dcc3b5aa765d61d8327deb882cf99";
        encryption.setEncryption("MD5");
        newPass = encryption.getHash(pass, false);
        System.out.println(newPass);

        Assert.assertEquals(newPass, passHash, "chech hash of password");

    }

    @Test(description = "this will hashing with SHA-1", priority = 2)
    public void testGetHashSHA1() throws NoSuchAlgorithmException {
        pass = "password";
        passHash = "5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8";
        encryption.setEncryption("SHA-1");
        newPass = encryption.getHash(pass, false);
        System.out.println(newPass);
        Assert.assertEquals(newPass, passHash, "chech hash of password");

    }

    @Test(description = "this will hashing with SHA-256", priority = 3)
    public void testGetHashSHA256() throws NoSuchAlgorithmException {
        pass = "password";
        passHash = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8";
        encryption.setEncryption("SHA-256");
        newPass = encryption.getHash(pass, false);
        System.out.println(newPass);
        Assert.assertEquals(newPass, passHash, "chech hash of password");

    }

    @Test(description = "this will hashing with SHA-386", priority = 4)
    public void testGetHashSHA386() throws NoSuchAlgorithmException {
        pass = "password";
        passHash = "a8b64babd0aca91a59bdbb7761b421d4f2bb38280d3a75ba0f21f2bebc45583d446c598660c94ce680c47d19c30783a7";
        encryption.setEncryption("SHA-384");
        newPass = encryption.getHash(pass, false);
        System.out.println(newPass);
        Assert.assertEquals(newPass, passHash, "chech hash of password");

    }

    @Test(description = "this will hashing with SHA-512", priority = 5)
    public void testGetHashSHA512() throws NoSuchAlgorithmException {
        pass = "password";
        passHash = "b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86";
        encryption.setEncryption("SHA-512");
        newPass = encryption.getHash(pass, false);
        System.out.println(newPass);
        Assert.assertEquals(newPass, passHash, "chech hash of password");

    }

    @Test(description = "this will decrypt with ROT13", priority = 5)
    public void tesRromROT() throws NoSuchAlgorithmException {
        String actual = "this is text to encrypt ";
        String fromRot13 = encryption.ToRot13(actual);
        String expected = encryption.ToRot13(fromRot13);
        System.out.println(actual);
        System.out.println(fromRot13);
        System.out.println(expected);

        Assert.assertEquals(actual, expected, "check ROT-13");

    }

}