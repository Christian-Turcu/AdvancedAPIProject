package register;

import org.testng.Assert;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class SolidPasswordTest {
    String password1;
    String password2;
    String msg;

    Boolean b;
    String expected;

    Password pwd;
    PasswordFactory pwf = new PasswordFactory();;

    @Test(description="this will test if passwords are the same", priority = 1)
    public void testConfirmPassworValidSame() {

        pwf = new PasswordFactory();
        pwd = pwf.getTest(Password.PASSWORD_TEST.SAME);

        password1 = "password";
        password2 = "passwor";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        expected = "Pasword do not Match";
        Assert.assertEquals(b.booleanValue(),true);

        // Assert.assertEquals(msg,expected);


    }

    @Test(description="this will test if passwords length is greater than 6", priority = 2)
    public void testConfirmPassworValidLength() {

        pwd = pwf.getTest(Password.PASSWORD_TEST.LENGTH);

        password1 = "pass";
        password2 = "pass";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        expected = "Password is not long enough";
        Assert.assertEquals(b.booleanValue(),true);

        //Assert.assertEquals(msg,expected);

    }

    @Test(description="this will test if password has a Capital letter", priority = 3)
    public void testConfirmPassworValidCapital() {
        pwd = pwf.getTest(Password.PASSWORD_TEST.CAPITAL);
        password1 = "password";
        password2 = "password";
        expected  = "Password should have a Capital Letter";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        Assert.assertEquals(b.booleanValue(),true);

       // Assert.assertEquals(msg,expected);



    }

    @Test(description="this will test if password has a Lower letter", priority = 4)
    public void testConfirmPassworValidLower() {

        pwd = pwf.getTest(Password.PASSWORD_TEST.LOWER);
        password1 = "PASSWORD";
        password2 = "PASSWORD";
        expected  = "Password should have a Lower Letter";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        Assert.assertEquals(b.booleanValue(),true);

        // Assert.assertEquals(msg,expected);

    }

    @Test(description="this will test if password has a Number", priority = 5)
    public void testConfirmPassworValidNumber() {
        pwd = pwf.getTest(Password.PASSWORD_TEST.NUMBER);
        password1 = "Password";
        password2 = "Password";
        expected  = "Password should have a Number";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        Assert.assertEquals(b.booleanValue(),true);

        // Assert.assertEquals(msg,expected);

    }

    @Test(description="this will test if password has been Compromised", priority = 6)
    public void testConfirmPassworCompromised() {
        pwd = pwf.getTest(Password.PASSWORD_TEST.COMPROMISED);
        password1 = "password";
        password2 = "password";
        expected  = "Password is compromised";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        Assert.assertEquals(b.booleanValue(),true);

        //Assert.assertEquals(msg,expected);

    }
    @Test(description="this will test if password has not been Compromised", priority = 7)
    public void testConfirmPassworNotCompromised() {
        pwd = pwf.getTest(Password.PASSWORD_TEST.COMPROMISED);
        password1 = "27Sept234567";
        password2 = "27Sept234567";
        expected  = "Password is Hacked";
        b = pwd.checkPassword(password1,password2);
        msg = pwd.getMessage();
        Assert.assertEquals(b.booleanValue(),false);

        //Assert.assertEquals(msg,expected);
    }
}