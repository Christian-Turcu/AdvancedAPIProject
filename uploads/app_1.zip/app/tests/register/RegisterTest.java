package register;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class RegisterTest {
    String name;
    String password;
    String confirmPassword;
    String email;
    String pin;

    String message;

    String reply;

    @BeforeMethod
    public void setUp() {
    }

    @AfterMethod
    public void tearDown() {
    }

    @Test
    public void testCheckIfValid() {
    }
    @Test(description="this will check if there is a blank entry", priority = 1, enabled = true)
    public void testCheckIfValidBlank() {
        name="";
        password="";
        confirmPassword="";
        email="";
        pin="";
        message = " Entries cant be Blank";
        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if password and confirm password the same", priority = 2, enabled = true)
    public void testCheckIfValidPaswordSame() {
        name="test";
        password="password";
        confirmPassword="passwor";
        email="a@b.c";
        pin="1234";
        message = "Passwords are not the Samre";
        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if password is short", priority = 3, enabled = true)
    public void testCheckIfValidPaswordShort() {
        name="test";
        password="pass";
        confirmPassword="pass";
        email="a@b.c";
        pin="1234";
        message = "Password has to have six characters";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if there capital letter", priority = 4, enabled = true)
    public void testCheckIfValidPaswordCapital() {
        name="test";
        password="password";
        confirmPassword="password";
        email="a@b.c";
        pin="1234";
        message = "Password has to have a capital letter";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if there lowercase letter", priority = 5, enabled = true)
    public void testCheckIfValidPaswordLower() {
        name="test";
        password="PASSWORD";
        confirmPassword="PASSWORD";
        email="a@b.c";
        pin="1234";
        message = "Password has to have a lower case letter";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if there Number", priority = 6, enabled = true)
    public void testCheckIfValidPaswordNumber() {
        name="test";
        password="Password";
        confirmPassword="Password";
        email="a@b.c";
        pin="1234";
        message = "Password need t6 have a Numeric";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if Email right format", priority = 7, enabled = true)
    public void testCheckIfValidEmail() {
        name="test";
        password="Passw0rd";
        confirmPassword="Passw0rd";
        email="a@b.c";
        pin="1234";
        message = "Enter a valid Email";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
    @Test(description="this will check if the pin is a srting Containing Numbers", priority = 8, enabled = true)
    public void testCheckIfValidPin() {
        name="test";
        password="Passw0rd";
        confirmPassword="Passw0rd";
        email="a@b.c";
        pin="1234a";
        message = "Enter a numeric Pin";

        Register register = new Register(name,password,confirmPassword,email,pin);
        reply = register.checkIfValid();
        System.out.println(message);
        Assert.assertEquals(reply, message);
    }
}