package database;

import model.Log;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import static org.testng.Assert.*;

public class LogDAOImplTest {
    LogDAOImpl  logger;
    Connection conn;
    Log testLog;
    int result;

    @BeforeMethod
    public void setUp() throws SQLException {
        Reporter.log("Setting up test ");
        logger = new LogDAOImpl();
        conn = Database.getConnection();
        testLog = new Log(1,"TEST","This is the first test log message", new Date().toString());
    }
    @AfterMethod
    public void tearDown() throws SQLException {
        Reporter.log("Closing Connection");
        Database.closeConnection(conn);
    }

    @Test(description="this will create a log", priority = 1, enabled = true)
    public void testCreate() throws SQLException {
        Reporter.log("TEst to Creata a log Entry using unique one with level Test");
        result = logger.create(testLog);
        Assert.assertEquals(result, 1);
    }

    @Test(description="this will delete a log", priority = 5, enabled = true)
    public void testDelete() throws SQLException {
        Reporter.log("Deleting unique Log with level Test");
       // result = logger.delete(testLog);
        Assert.assertEquals(1, result);
    }

    @Test(description="this will Read all logs", priority = 3)
    public void testReadAll() throws SQLException {
        Reporter.log("Checking Resultset for entry with created log having level Test");
        List<Log> actualList = logger.readAll();
        boolean contains =actualList.stream().anyMatch(p -> p.getLevel().equals("TEST"));
        Assert.assertEquals( contains, true, "Comparison of List");
    }

    @Test(description="this will test for a log with level WARN", priority = 4)
    public void testReadFilteredQuery() throws SQLException {
        Reporter.log("TEst to Creata a log Entry using unique one with level Test");
        String table = "log";
        String column = "level";
        String result = "TEST";
        List<Log> l = logger.readTableColumnQuery(table,column,result);
        boolean contains =l.stream().anyMatch(p -> p.getLevel().equals("TEST"));

        Assert.assertEquals( contains, true, "Comparison of List");

    }

    @Test(description="this will test for SQLinjection", priority = 5)
    public void testSQLinjection() throws SQLException {
        Reporter.log("Test to check for SQL injection");
        String table = "log";
        String column = "level";
        //SQLInjection No SQL level ever placed in database getting all back with 1=1
        String result = "SQL' or '1=1";
        List<Log> l = logger.readTableColumnQuery(table,column,result);
        System.out.println(l);
        System.out.println(l.isEmpty());
        Assert.assertEquals( true, true, "SQLInjection");

    }

    @Test(description="this will test for SQLinjection", priority = 6)
    public void testSQLinjectionVersion() throws SQLException {
        Reporter.log("Test for sql injection to find the version of SQLite in use");
        String table = "log";
        String column = "level";
        //SQLInjection FIND VERSION PROBLEM WITH UNION NEED TO HAVE SAME NUMBER OF COLUMNS
        String result = "' UNION SELECT NULL,NULL, NULL, sqlite_version()--";
        List<Log> l = logger.readTableColumnQuery(table,column,result);
        System.out.println(l);
        System.out.println(l.isEmpty());

        Assert.assertEquals( true, true, "SQLInjection version");

    }
}

