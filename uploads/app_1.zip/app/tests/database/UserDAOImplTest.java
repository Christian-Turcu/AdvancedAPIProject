package database;

import model.User;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import static org.testng.Assert.*;

public class UserDAOImplTest {
    UserDAOImpl  userDAO;
    Connection conn;
    User testUser;
    int result;

    @BeforeMethod
    public void setUp() throws SQLException {
        Reporter.log("Setting up BeforeMethod");
        userDAO = new UserDAOImpl();
        conn = Database.getConnection();
        testUser = new User(1,"testUser","password", "test@test.com","TEST","0000","LOCKED");
    }

    @AfterMethod
    public void tearDown() throws SQLException {
        Reporter.log("Closing Connection");
        Database.closeConnection(conn);
    }

    @Test(description="this will create a Test User", priority = 1)
    public void testCreate() throws SQLException {
        Reporter.log("Test to Create a unique User");
        result = userDAO.create(testUser);
        Assert.assertEquals(result, 1);
    }

    @Test(description="this will Read one log", priority = 3, enabled = false)
    public void testReadOne() {
    }

    @Test(description = "this will update the testUser", priority = 4, enabled = false)
    public void testUpdate() {
    }

    @Test(description="this will delete testUser", priority = 3, enabled = true)
    public void testDelete() throws SQLException {
        Reporter.log("Deleting unique Log with level Test");
        result = userDAO.delete(testUser);
        Assert.assertEquals(result, 1);
    }
    @Test(description="this will Read all Users", priority = 2, enabled = true)
    public void testReadAll() throws SQLException {
        Reporter.log("Checking Resultset for entry with unique User");
        List<User> actualList = userDAO.readAll();
        boolean contains =actualList.stream().anyMatch(p -> p.getEmail().equals("test@test.com"));

        Assert.assertEquals( contains, true, "Comparison of List");
    }
    @Test
    public void testCheckExists() {
    }

    @Test
    public void testReadLoggedInUser() {
    }
}